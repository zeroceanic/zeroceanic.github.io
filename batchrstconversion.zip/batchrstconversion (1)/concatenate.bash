#!/bin/bash
echo '<?xml version="1.0" encoding="utf-8" ?>' > index.xml
echo '<!DOCTYPE article>' >> index.xml
echo '<article xmlns="http://docbook.org/ns/docbook" version="5.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:xi="http://www.w3.org/2001/XInclude">' >> index.xml
echo '<title>Index</title>' >> index.xml
for file in $(ls *.rst); do
 echo $file
    pandoc -f rst -t docbook --template=pandoc_template.txt $file >> index.xml
done
echo '</article>' >> index.xml
sed -i '' 's/<br>//g' index.xml
